#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

EvilStorePath="/var/lib/pandora/evilstore/stock"
dbPath="/var/lib/pandora/db/user/evilstore.db";

###########################################################################
# FUNCTIONS
###########################################################################

copy_file_with_suffix() {

	src_file="$1"
	dest_dir="$2"
	base_name=$(basename "$src_file")
	dest_file="$dest_dir/$base_name"

	if [ -e "$dest_file" ]; then

		suffix=1

		while [ -e "${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}" ]; do
			((suffix++))
		done

		dest_file="${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}"

	fi

	cp "$src_file" "$dest_file"
	echo "$dest_file"
}

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"


###########################################################################
# LINPEAS.SH
###########################################################################

targetFile="content/linpeas.sh";
echo "FAILED">status.info

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="PRIVESC"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="LINUX"
		desc="Linux Privilege Escalation Awesome Script"
		help="
AUTHOR:
URL:

Ceci est un exemple de texte long
Il peut contenir plusieurs lignes, des ponctuations, et d'autres caractères spéciaux.
Par exemple :
- Une liste avec des puces.
- Une autre ligne de texte.

Les sauts de ligne sont également préservés."
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"

			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		else
			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "content/linpeas.sh" "$EvilStorePath/$categorylower/")
		basename=$(basename "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, DATE) VALUES ('$categoryID', '$os', '$filename', '$desc', '$encoded_help', '$hash', $date);"
			echo "SUCCESS">status.info
		fi
	else
		echo "File is already present in EvilStore"
	fi
fi

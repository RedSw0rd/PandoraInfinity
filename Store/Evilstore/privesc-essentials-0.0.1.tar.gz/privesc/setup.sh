#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

EvilStorePath="/var/lib/pandora/evilstore/stock"

###########################################################################
# FUNCTIONS
###########################################################################

copy_file_with_suffix() {

	src_file="$1"
	dest_dir="$2"
	base_name=$(basename "$src_file")
	dest_file="$dest_dir/$base_name"

	if [ -e "$dest_file" ]; then

		suffix=1

		while [ -e "${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}" ]; do
			((suffix++))
		done

		dest_file="${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}"

	fi

	mv "$src_file" "$dest_file"
	echo "$dest_file"
}

###########################################################################
# LINPEAS.SH
###########################################################################

# COPY FILE
filename=$(copy_file_with_suffix "content/linpeas.sh" "/var/lib/pandora/evilstore/stock/privesc/linux/")
basename=$(basename "$filename")

if [[ -e "$filename" ]]
then
	hash=$(md5sum "$filename" | awk '{ print $1 }')
	dbPath="/var/lib/pandora/db/user/evilstore.db";

	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		type="PRIVESC"
		os="LINUX"
		desc="Linux Privilege Escalation Awesome Script"
		help=$(cat <<EOF

		AUTHOR:
		URL:

		Ceci est un exemple de texte long
		Il peut contenir plusieurs lignes, des ponctuations, et d'autres caractères spéciaux.
		Par exemple :
		- Une liste avec des puces.
		- Une autre ligne de texte.

		Les sauts de ligne sont également préservés.
		EOF
		)
		date=$(date +%s)

		sqlite3 "$dbPath" <<EOF
		INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, DATE) VALUES ('$type', '$os', 'filename', '$desc', '$help', '$hash', $date);
		EOF
	else
		echo "File is already present in EvilStore"
	fi
fi

#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

EvilStorePath="/var/lib/pandora/evilstore/stock"
dbPath="/var/lib/pandora/db/user/evilstore.db";

###########################################################################
# FUNCTIONS
###########################################################################

copy_file_with_suffix() {

	src_file="$1"
	dest_dir="$2"
	base_name=$(basename "$src_file")
	dest_file="$dest_dir/$base_name"

	if [ -e "$dest_file" ]; then

		suffix=1

		while [ -e "${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}" ]; do
			((suffix++))
		done

		dest_file="${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}"

	fi

	cp "$src_file" "$dest_file"
	echo "$dest_file"
}

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"


###########################################################################
# LINPEAS.SH
###########################################################################

targetFile="content/linpeas.sh";
echo "FAILED">status.info

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="PRIVESC"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="LINUX"
		desc="Linux Privilege Escalation Awesome Script"
		help="AUTHOR:Peass-ng
URL:https://github.com/peass-ng/PEASS-ng

PEASS-ng - Privilege Escalation Awesome Scripts SUITE new generation

These tools search for possible local privilege escalation paths that you could exploit and print them to you with nice colors
so you can recognize the misconfigurations easily.

All the scripts/binaries of the PEAS suite should be used for authorized penetration testing and/or educational purposes only.
Any misuse of this software will not be the responsibility of the author or of any other collaborator.
Use it at your own machines and/or with the owner's permission.

LinPEAS - Linux Privilege Escalation Awesome Script.
LinPEAS is a script that search for possible paths to escalate privileges on Linux/Unix*/MacOS hosts.
The checks are explained on book.hacktricks.xyz

Check the Local Linux Privilege Escalation checklist from book.hacktricks.xyz.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"

			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		else
			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		basename=$(basename "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, DATE) VALUES ('$categoryID', '$os', '$filename', '$desc', '$encoded_help', '$hash', $date);"
			echo "SUCCESS">status.info
		fi
	else
		echo "|!| File is already present in EvilStore\n"
	fi
fi

###########################################################################
#
###########################################################################

targetFile="content/linpeas_linux_arm64";
echo "FAILED">status.info

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="PRIVESC"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="LINUX"
		desc="Linux Privilege Escalation Awesome Script"
		help="AUTHOR:Peass-ng
URL:https://github.com/peass-ng/PEASS-ng

PEASS-ng - Privilege Escalation Awesome Scripts SUITE new generation

These tools search for possible local privilege escalation paths that you could exploit and print them to you with nice colors
so you can recognize the misconfigurations easily.

All the scripts/binaries of the PEAS suite should be used for authorized penetration testing and/or educational purposes only.
Any misuse of this software will not be the responsibility of the author or of any other collaborator.
Use it at your own machines and/or with the owner's permission.

LinPEAS - Linux Privilege Escalation Awesome Script.
LinPEAS is a script that search for possible paths to escalate privileges on Linux/Unix*/MacOS hosts.
The checks are explained on book.hacktricks.xyz

Check the Local Linux Privilege Escalation checklist from book.hacktricks.xyz.

Binary Release.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"

			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		else
			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		basename=$(basename "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, DATE) VALUES ('$categoryID', '$os', '$filename', '$desc', '$encoded_help', '$hash', $date);"
			echo "SUCCESS">status.info
		fi
	else
		echo "|!| File is already present in EvilStore\n"
	fi
fi

###########################################################################
#
###########################################################################

targetFile="content/linpeas_linux_arm";
echo "FAILED">status.info

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="PRIVESC"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="LINUX"
		desc="Linux Privilege Escalation Awesome Script"
		help="AUTHOR:Peass-ng
URL:https://github.com/peass-ng/PEASS-ng

PEASS-ng - Privilege Escalation Awesome Scripts SUITE new generation

These tools search for possible local privilege escalation paths that you could exploit and print them to you with nice colors
so you can recognize the misconfigurations easily.

All the scripts/binaries of the PEAS suite should be used for authorized penetration testing and/or educational purposes only.
Any misuse of this software will not be the responsibility of the author or of any other collaborator.
Use it at your own machines and/or with the owner's permission.

LinPEAS - Linux Privilege Escalation Awesome Script.
LinPEAS is a script that search for possible paths to escalate privileges on Linux/Unix*/MacOS hosts.
The checks are explained on book.hacktricks.xyz

Check the Local Linux Privilege Escalation checklist from book.hacktricks.xyz.

Binary Release.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"

			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		else
			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		basename=$(basename "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, DATE) VALUES ('$categoryID', '$os', '$filename', '$desc', '$encoded_help', '$hash', $date);"
			echo "SUCCESS">status.info
		fi
	else
		echo "|!| File is already present in EvilStore\n"
	fi
fi

###########################################################################
#
###########################################################################

targetFile="content/linpeas_linux_amd64";
echo "FAILED">status.info

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="PRIVESC"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="LINUX"
		desc="Linux Privilege Escalation Awesome Script"
		help="AUTHOR:Peass-ng
URL:https://github.com/peass-ng/PEASS-ng

PEASS-ng - Privilege Escalation Awesome Scripts SUITE new generation

These tools search for possible local privilege escalation paths that you could exploit and print them to you with nice colors
so you can recognize the misconfigurations easily.

All the scripts/binaries of the PEAS suite should be used for authorized penetration testing and/or educational purposes only.
Any misuse of this software will not be the responsibility of the author or of any other collaborator.
Use it at your own machines and/or with the owner's permission.

LinPEAS - Linux Privilege Escalation Awesome Script.
LinPEAS is a script that search for possible paths to escalate privileges on Linux/Unix*/MacOS hosts.
The checks are explained on book.hacktricks.xyz

Check the Local Linux Privilege Escalation checklist from book.hacktricks.xyz.

Binary Release.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"

			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		else
			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		basename=$(basename "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, DATE) VALUES ('$categoryID', '$os', '$filename', '$desc', '$encoded_help', '$hash', $date);"
			echo "SUCCESS">status.info
		fi
	else
		echo "|!| File is already present in EvilStore\n"
	fi
fi

###########################################################################
#
###########################################################################

targetFile="content/linpeas_linux_386";
echo "FAILED">status.info

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="PRIVESC"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="LINUX"
		desc="Linux Privilege Escalation Awesome Script"
		help="AUTHOR:Peass-ng
URL:https://github.com/peass-ng/PEASS-ng

PEASS-ng - Privilege Escalation Awesome Scripts SUITE new generation

These tools search for possible local privilege escalation paths that you could exploit and print them to you with nice colors
so you can recognize the misconfigurations easily.

All the scripts/binaries of the PEAS suite should be used for authorized penetration testing and/or educational purposes only.
Any misuse of this software will not be the responsibility of the author or of any other collaborator.
Use it at your own machines and/or with the owner's permission.

LinPEAS - Linux Privilege Escalation Awesome Script.
LinPEAS is a script that search for possible paths to escalate privileges on Linux/Unix*/MacOS hosts.
The checks are explained on book.hacktricks.xyz

Check the Local Linux Privilege Escalation checklist from book.hacktricks.xyz.

Binary Release.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"

			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		else
			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		basename=$(basename "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, DATE) VALUES ('$categoryID', '$os', '$filename', '$desc', '$encoded_help', '$hash', $date);"
			echo "SUCCESS">status.info
		fi
	else
		echo "|!| File is already present in EvilStore\n"
	fi
fi

###########################################################################
#
###########################################################################

targetFile="content/linpeas_darwin_amd64";
echo "FAILED">status.info

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="PRIVESC"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="LINUX"
		desc="Linux Privilege Escalation Awesome Script"
		help="AUTHOR:Peass-ng
URL:https://github.com/peass-ng/PEASS-ng

PEASS-ng - Privilege Escalation Awesome Scripts SUITE new generation

These tools search for possible local privilege escalation paths that you could exploit and print them to you with nice colors
so you can recognize the misconfigurations easily.

All the scripts/binaries of the PEAS suite should be used for authorized penetration testing and/or educational purposes only.
Any misuse of this software will not be the responsibility of the author or of any other collaborator.
Use it at your own machines and/or with the owner's permission.

LinPEAS - Linux Privilege Escalation Awesome Script.
LinPEAS is a script that search for possible paths to escalate privileges on Linux/Unix*/MacOS hosts.
The checks are explained on book.hacktricks.xyz

Check the Local Linux Privilege Escalation checklist from book.hacktricks.xyz.

Binary Release.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"

			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		else
			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		basename=$(basename "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, DATE) VALUES ('$categoryID', '$os', '$filename', '$desc', '$encoded_help', '$hash', $date);"
			echo "SUCCESS">status.info
		fi
	else
		echo "|!| File is already present in EvilStore\n"
	fi
fi

###########################################################################
#
###########################################################################

targetFile="content/linpeas_darwin_arm64";
echo "FAILED">status.info

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="PRIVESC"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="LINUX"
		desc="Linux Privilege Escalation Awesome Script"
		help="AUTHOR:Peass-ng
URL:https://github.com/peass-ng/PEASS-ng

PEASS-ng - Privilege Escalation Awesome Scripts SUITE new generation

These tools search for possible local privilege escalation paths that you could exploit and print them to you with nice colors
so you can recognize the misconfigurations easily.

All the scripts/binaries of the PEAS suite should be used for authorized penetration testing and/or educational purposes only.
Any misuse of this software will not be the responsibility of the author or of any other collaborator.
Use it at your own machines and/or with the owner's permission.

LinPEAS - Linux Privilege Escalation Awesome Script.
LinPEAS is a script that search for possible paths to escalate privileges on Linux/Unix*/MacOS hosts.
The checks are explained on book.hacktricks.xyz

Check the Local Linux Privilege Escalation checklist from book.hacktricks.xyz.

Binary Release.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"

			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		else
			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		basename=$(basename "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, DATE) VALUES ('$categoryID', '$os', '$filename', '$desc', '$encoded_help', '$hash', $date);"
			echo "SUCCESS">status.info
		fi
	else
		echo "|!| File is already present in EvilStore\n"
	fi
fi





















